package dbtest;

import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner keyScan = new Scanner(System.in);
    SignUp signup = new SignUp();
    Login login = new Login();
    Edit edit = new Edit();
    Delete delete = new Delete();
    Finish finish = new Finish();
    Leave leave = new Leave();
    Insert insert = new Insert();
    Update update = new Update();
    Share share = new Share();


    while (true) {
      System.out.println("\n-----------------일정관리 시스템------------------");
      System.out.println("\n1. 로그인   2. 회원가입   3. 관리자 접속   0. 종료");
      System.out.print("번호 입력 : ");
      String num = keyScan.nextLine();

      if (num.equals("1")) {
        loop : while (true) {
          login.login();
          String id = login.id;

          if (id.equals("0")) { break; }

          while (true) {
            System.out.println("\n---------메뉴----------");
            System.out.println("\n메뉴를 선택하여 주세요.");
            // 최종메뉴 System.out.println("1.개인일정 2.완료일정 3.공유일정 4.회원정보관리 0.로그아웃");
            // 개인일정메뉴 System.out.println("1.일정추가 2.일정수정 3.일정삭제 4.일정완료처리 5.일정공유 0.뒤로가기");
            // 완료일정메뉴 System.out.println("1.일정삭제 0.뒤로가기");
            // 공유일정메뉴 System.out.println("1.일정삭제 0.뒤로가기");
            System.out.println("\n1. 일정추가\n2. 일정수정\n3. 일정삭제\n4. 일정완료처리\n5. 일정공유\n6. 회원정보관리\n0. 로그아웃\n");
            System.out.print("메뉴 입력 : ");
            String lognum = keyScan.nextLine();

            if (lognum.equals("1")) {insert.insert(id);}
            else if (lognum.equals("2")) {update.update(id);}
            else if (lognum.equals("3")) {delete.delete(id);}
            else if (lognum.equals("4")) {finish.finish(id);}
            else if (lognum.equals("5")) {share.share(id);}
            else if (lognum.equals("6")) {
              while (true) {
                System.out.println("\n-----회원정보관리-----");
                System.out.println("\n메뉴를 선택하여 주세요.");
                System.out.println("\n1. 회원정보 수정\n2. 회원탈퇴\n0. 뒤로가기\n");
                System.out.print("번호 입력 : ");
                String infonum = keyScan.nextLine();
                if (infonum.equals("1")) {edit.edit(id);}
                else if (infonum.equals("2")) {leave.leave(id); break;}
                else if (infonum.equals("0")) {break;}
                else {System.out.println("\n잘못 입력하셨습니다. 다시 입력하여 주세요."); continue;}
              }
            }
            else if (lognum.equals("0")) {System.out.println("\n로그아웃 되었습니다.\n"); break loop;}
            else {System.out.println("\n잘못 입력하셨습니다. 다시 입력하여 주세요."); continue;}
          }
        }
      }
      else if (num.equals("2")) {signup.signup();}
      else if (num.equals("0")) {System.out.println("\n프로그램을 종료합니다."); break;}
      else {System.out.println("\n잘못 입력하셨습니다. 다시 입력하여 주세요.");}
    }
  }
}